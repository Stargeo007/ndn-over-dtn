#!/bin/bash

docker stop $(docker ps -a -q)
docker network remove umobile1
docker network remove umobile2

