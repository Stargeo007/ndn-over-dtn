#!/bin/bash

echo "Starting DTN daemon"
dtnd -i eth0 -c /confs/dtn_$1.conf &

sleep 5

echo "Starting NDN daemon"
cp /confs/nfd_$1.conf /usr/local/etc/ndn/nfd.conf
nfd-start &

wait

