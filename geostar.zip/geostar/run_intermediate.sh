#!/bin/bash



# check if containers networks exist and create them, if they do not.
docker network create --subnet=172.18.0.0/16 umobile1
docker network create --subnet=172.20.0.0/16 umobile2

# make sure our base image is already build.
docker build . -t geostar

# Run umobile2
docker run --rm -dit --net umobile2 --ip 172.20.0.2 --entrypoint bash  --name umobile2 -v ${PWD}/confs_intermediate:/confs geostar 

docker exec -dit umobile2 /bin/bash -c 'dtnd -i eth0 -c /confs/dtn_umobile2.conf& cp /confs/nfd_umobile2.conf /usr/local/etc/ndn/nfd.conf && nfd-start & wait;'

# Run intermediate
docker run --rm -dit --net umobile2 --entrypoint bash --name intermediate -v ${PWD}/confs_intermediate:/confs geostar 


# Run umobile1
docker run --rm -dit --net umobile1 --ip 172.18.0.2 --entrypoint bash  --name umobile1 -v ${PWD}/confs_intermediate:/confs geostar 

docker exec -dit umobile1 /bin/bash -c 'dtnd -i eth0 -c /confs/dtn_umobile1.conf& cp /confs/nfd_umobile1.conf /usr/local/etc/ndn/nfd.conf && nfd-start & wait;'


docker network connect umobile1 intermediate

docker exec -dit intermediate /bin/bash -c 'dtnd -c /confs/dtn_intermediate.conf& wait;'

